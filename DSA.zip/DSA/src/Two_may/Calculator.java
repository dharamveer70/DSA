package Two_may;

@FunctionalInterface
interface CalculatorImp {
      void add();

}


public class Calculator  {
    public static void main(String[] args) {
        CalculatorImp cal = () -> System.out.println("Here We Came ");
        cal.add();

    }


}
