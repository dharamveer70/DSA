package Five;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamApi {
    public static void main(String[] args) {

        int[] numbersArray = {1, 3, 4, 6, 2, 7};
        List<Integer> numbers = Arrays.stream(numbersArray).boxed().sorted().collect(Collectors.toList());
        System.out.println(numbers);







      //  List<Integer> numbers =	Arrays.asList(1,3,3,4,	4,	6,	2,	7);
       // numbers.stream().distinct().collect(Collectors.toList());
       // System.out.println(numbers);
    //    System.out.println(numbers.stream().distinct().collect(Collectors.toList()));
     //   System.out.println(numbers.stream().sorted().collect(Collectors.toList()));


//        numbers.stream().filter((number)	->	(number %	2	!=	0)).forEach(
//                number -> System.out.print(number));



    }





}
