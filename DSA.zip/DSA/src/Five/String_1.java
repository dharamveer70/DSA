package Five;

public class String_1 {
    public static void main(String[] args) {
        String name = "Dharamveer";
        int length = name.length();
        String rev_name = "";
        for (int i =length-1;i>=0;i--){
            rev_name = rev_name+name.charAt(i);
        }
        System.out.println(rev_name);
    }
}
