package Five;

public class OneTon {

    // Private static variable to hold the single instance of the class
    private static OneTon instance;

    // Private constructor to prevent instantiation from outside
    private OneTon(){};
    // Public static method to get the single instance of the class

    public static OneTon getInstance(){
        if (instance==null){
            // Lazy initialization: Create the instance only when needed
            instance= new OneTon();
        }
        return instance;
    }
}
