package Five;

public  final class ImmutableClass {

    private final String name= "Veer" ;
    private final  int roll = 25;

    private ImmutableClass(String name ,int roll ){
        name = this.name;
        roll = this.roll;
    }
    public int getRoll(){
        return  roll;
    }
    public String getName(){
        return  name;
    }

}
