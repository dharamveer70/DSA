package Five;

import java.util.*;
import java.util.stream.Collectors;

public class Testone {
    public static void main(String[] args) {
        int arr[]  = {2,3,4,5};

        for(int num1:arr){
            int num = num1*num1*num1;
            System.out.println(num);

        }


//        int number = Arrays.stream(arr).boxed().map(i->i*i*i).max(Integer::compareTo).get();
//        System.out.println(number);

    }
}
