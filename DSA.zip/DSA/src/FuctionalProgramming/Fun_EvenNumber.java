package FuctionalProgramming;

import java.util.List;

public class Fun_EvenNumber {
    public static void main(String[] args) {
        //    printEvenNumber(List.of( 5, 6, 8, 69, 78, 45, 1, 5, 86));    }
        //Its Structured Way
//    private static void printEvenNumber(List<Integer> number) {
//        int evenCount = 0;
//        for (int num : number) {
//            if (num%2 == 0){
//                evenCount++;
//                System.out.println(num);
//            }
//        }
//        System.out.println("Total Count Of Even Count "+evenCount);
//          }

        List<Integer>  printEvenNumber= (List.of( 5,8, 69, 78, 45, 1, 5, 86,74));
         //Just In One Line
       printEvenNumber.stream().filter(n->n%2!=0).forEach(System.out::println);
        //   Long count = printEvenNumber.stream().filter(n->n%2 == 0).count();
     //   System.out.println("CountIng Of Not Even Number - "+count);



        printEvenNumber.stream().filter(n->n%2!=0).map(n ->n*n).forEach(System.out::println);
//        printEvenNumber.stream()
//                .filter(n -> n % 2 == 0)
//                .peek(System.out::println) // Prints each even number
//                .count();

        //printEvenNumber(printEvenNumber);

}
    public static boolean isEven(int number) {
        return number % 2 == 0;
    }
    private static  void  printEvenNumber(List<Integer> num){
        num.stream().filter(Fun_EvenNumber::isEven).forEach(System.out::println);
    }


            }