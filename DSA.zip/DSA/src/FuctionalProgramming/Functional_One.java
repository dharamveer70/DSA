package FuctionalProgramming;

import java.util.Arrays;
import java.util.List;

public class Functional_One {
    public static void main(String[] args) {
        //Structured Way
        // printAllNumberInListStructured(List.of(1,5,8,6,2,8,2,9,4,11,89,9));
        //Functional Way
        printAllNumberInListFunctional(List.of(1, 5, 8, 6, 2, 8, 2, 9, 4, 11, 89, 9));

    }
//    private static void printAllNumberInListStructured(List<Integer> numbers){
//        for(int number : numbers){
//            System.out.println(number);
//        }


    private static void printAllNumberInListFunctional(List<Integer> num){
      //  num.stream().forEach(c-> System.out.println(c));
        num.stream().forEach(System.out::println);

    }


}
