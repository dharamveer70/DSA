package FuctionalProgramming;

import java.util.List;

public class Functional_Exercise {
    public static void main(String[] args) {
        List<String> courses = List.of("Spring","Spring Mvc","SpringBoot","Api","Docker","Java");
       // courses.stream().forEach(System.out::println);
        //Use Contains Method
    //    courses.stream().filter(course -> course.contains("Spring") ).forEach(System.out::println);

      //  courses.stream().filter(course -> course.length() >= 4 ).forEach(System.out::println);

        //Find Out Courses Length with Name

        courses.stream().map(c ->c+" Courses Length  "+ c.length()).forEach(System.out::println);


    }
}

