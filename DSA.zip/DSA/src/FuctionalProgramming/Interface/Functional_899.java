package FuctionalProgramming.Interface;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class Functional_899 {
    public static void main(String[] args) {
        List<Integer> number = List.of(12,11,89,5,8,6,9,4,5,8,6,2,8,6,4,6);


        number.stream().filter(n->n%2 == 0).map(x->x*x).forEach(System.out::println);


    number.stream().filter(n->n%2 !=0).reduce(0,Integer::sum);
      //  System.out.println(number);


    }
}
//    List<Integer> num =
//            number.stream().map(x->x*x*x).collect(Collectors.toList());
// System.out.println(num);
