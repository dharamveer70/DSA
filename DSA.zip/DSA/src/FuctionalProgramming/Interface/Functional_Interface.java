package FuctionalProgramming.Interface;

import java.util.List;
import java.util.stream.Collectors;

public class Functional_Interface {
    @SuppressWarnings("unused")
    public static void main(String[] args) {
        List<Integer> number =List.of(12,85,9,6,48,5,10,10,85);

        //remove dublipcate
        List<Integer> remove = number.stream().distinct().collect(Collectors.toList());
        System.out.println(remove);

      //List<Integer> num =
             // number.stream().filter(n->n%2==0).map(n->n*n).forEach(System.out::println);
              //collect(Collectors.toList());
       // System.out.println(num);

        

    }
}
