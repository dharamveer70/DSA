package FuctionalProgramming;

import java.util.List;

public class AddStructured {
    public static void main(String[] args) {
        List<Integer>  number = List.of(1,5,89,68,5,24,5,56,96,51);
       int sum =  number.stream().reduce(0,Integer::sum);
        System.out.println(sum);

    }
//    private static int AddListStructured(List<Integer> number) {
//        int sum = 0;
//        for(int num:number){
//            sum +=num;
//        }
//        return sum;
//    }
}
