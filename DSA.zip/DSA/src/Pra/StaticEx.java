package Pra;

import java.util.HashMap;
import java.util.Map;

public class StaticEx {
    int num ;
    String name ;

    String [] numer = {"Ram","Shyam"};


   static String company ="Gateway Group Of Companies ";

    public StaticEx(int num,String name)
    {
        this.num= num;
        this.name= name;
    }
    void display (){
        System.out.println(name+" "+num+" "+company);
    }

    public static void main(String[] args) {

        StaticEx e1 = new StaticEx(10,"Dharamveer");
                 e1.display();
        StaticEx e2 = new StaticEx(1,"jai");
        e2.display();

        Map<String ,String>  map = new HashMap<>();
        map.put("Dharamveer","AsthaRaje");
        System.out.println(map);


         }
}

