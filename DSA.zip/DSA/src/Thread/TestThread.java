package Thread;

public class TestThread {
    public static void main(String[] args) {
        System.out.println("Hello world");
//        System.out.println(Thread.currentThread().getName());

        World world =  new World();
        Thread t1 = new Thread(world);
        t1.start();

        for(;;){
            System.out.println("Hello");
        }





    }
}
