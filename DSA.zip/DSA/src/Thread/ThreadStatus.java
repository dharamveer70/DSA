package Thread;

public class ThreadStatus extends Thread{

    @Override
    public void run() {
        super.run();
    }



    public static void main(String[] args) {
        ThreadStatus t1 = new ThreadStatus();
        System.out.println(t1.getState());
        t1.start();
        System.out.println(t1.getState());
        t1.run();
        System.out.println(t1.getState());
    }
}
