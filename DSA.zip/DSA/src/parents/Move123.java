package parents;

public class Move123 {
    public static void main(String[] args) {
        String Name = "Veer";
        int num = Name.length();
        String Name2 = "";
    for(int i = num-1;i>=0;i--){
        Name2 =Name2+Name.charAt(i);
    }
        System.out.println(Name2);
}}
