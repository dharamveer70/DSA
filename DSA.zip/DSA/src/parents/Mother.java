package parents;

public class Mother extends Father {
    void car()
    {
        System.out.println("We Have Also Car Here Its Big One ");

    }

    public static void main(String[] args) {
        Father f1 = new Father();
    f1.house();
    f1.money();

}}
