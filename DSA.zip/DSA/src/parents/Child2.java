package parents;

public interface Child2 {
}
interface A{
     void BMW();
    }
    interface B {
         void Audi();
    }

class C  implements A,B {
    @Override
    public void BMW() {
        System.out.println("Hey We Have BMW Also Bro ");
    }

    @Override
    public void Audi() {
        System.out.println("Hey We Have Audi Bro");

    }

    public static void main(String[] args) {
        C c1 =  new C();
        c1.BMW();
        c1.Audi();
    }
}

