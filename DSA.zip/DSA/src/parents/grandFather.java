package parents;

public class grandFather {
    void money(){
        System.out.println("Bron Rich Bro Sab Kuch Hai Apne Pass --");
    }
}
