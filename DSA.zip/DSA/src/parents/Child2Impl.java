package parents;

public class Child2Impl implements Child2 {
}
