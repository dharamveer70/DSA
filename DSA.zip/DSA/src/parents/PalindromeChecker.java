package parents;

import java.util.stream.IntStream;

public class PalindromeChecker {
    public static boolean isPalindrome(String str) {
        String cleanedStr = str.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
        return IntStream.range(0, cleanedStr.length() / 2)
                .allMatch(i -> cleanedStr.charAt(i) == cleanedStr.charAt(cleanedStr.length() - i - 1));
    }

    public static void main(String[] args) {
        String testString = "A man, a plan, a canal, Panama!";
        System.out.println("Is \"" + testString + "\" a palindrome? " + isPalindrome(testString));
        PalindromeChecker p1 = new PalindromeChecker();
        System.out.println(p1.name("veer"));
    }

    public String name(String name2){
        return "Dharamveer";
    }
    public void name(int number){

    }





}
