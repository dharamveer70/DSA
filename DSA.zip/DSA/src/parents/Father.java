package parents;

public class Father extends grandFather{
    void house(){
        System.out.println("We Have A Big House");
    }

    public static void main(String[] args) {


        grandFather gf = new grandFather();
        gf.money();

    }

}
