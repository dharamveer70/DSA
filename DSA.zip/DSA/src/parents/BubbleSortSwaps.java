package parents;

import java.util.Scanner;

public class BubbleSortSwaps {


    public static void main(String[] args) {
        String s1 = "Java";

        String s2 = new String("Java").intern();

        StringBuilder sb1 = new StringBuilder("Java");

        StringBuilder sb2 = new StringBuilder("Java");

        System.out.println(s1==s2); //false

        System.out.println(s1.equals(s2)); //true

        System.out.println(sb1.equals(sb2)); //false

        System.out.println(sb1.toString().equals(sb2.toString())); //true








    }

//    public static void bubbleSortWithSwaps(int[] arr, int M) {
//        int n = arr.length;
//        int totalSwaps = 0;
//
//        for (int i = 0; i < M && i < n; i++) {
//            int swaps = 0;
//
//            for (int j = 0; j < n - 1 - i; j++) {
//                if (arr[j] < arr[j + 1]) {
//                    // Swap elements
//                    int temp = arr[j];
//                    arr[j] = arr[j + 1];
//                    arr[j + 1] = temp;
//                    swaps++;
//                    totalSwaps++;
//                }
//            }
//
//            // If no swaps are made in this iteration, break early
//            if (swaps == 0) {
//                break;
//            }
//        }
//
//        System.out.println(totalSwaps);
//    }

//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//
//        System.out.print("Enter the value of M: ");
//        int M = scanner.nextInt();
//
//        System.out.print("Enter the size of the array: ");
//        int size = scanner.nextInt();
//
//        int[] arr = new int[size];
//        System.out.println("Enter the elements of the array:");
//        for (int i = 0; i < size; i++) {
//            arr[i] = scanner.nextInt();
//        }




     //   System.out.println();


       // bubbleSortWithSwaps(arr, M);

}
