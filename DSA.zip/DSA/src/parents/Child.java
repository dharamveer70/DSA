package parents;

public class Child extends Mother  {
    public static void main(String[] args) {
        Mother m1 = new Mother();
        m1.car();
        m1.house();
        m1.money();
    }
}
