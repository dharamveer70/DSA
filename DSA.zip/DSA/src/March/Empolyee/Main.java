package March.Empolyee;

import java.util.ArrayList;

abstract class Employee{

    private String  name ;
    private int id;

    public Employee(String name,int id){
        this.name = name;
        this.id =id;
    }
    public String getName(){
        return  name;
    }
    public int getId(){
        return id;
    }
    public abstract double calculateSalary();

    @Override
    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", id=" + id +
                "Salary ='" + calculateSalary() +
                '}';
    }
}
class FullTimeEmployee extends Employee{
    private double monthlySalary;
    public FullTimeEmployee(String name, int id,double monthlySalary) {
        super(name, id);
        this.monthlySalary = monthlySalary;
    }@Override
    public double calculateSalary() {
        return 0;
    }
}
class PartEmployee extends Employee {
    private double hoursWorked;
    private double hourlyRate;

    public PartEmployee(String name ,int id,double hoursWorked,double hourlyRate){
        super(name ,id);
        this.hourlyRate = hourlyRate;
        this.hoursWorked = hoursWorked;

    }
    @Override
    public double calculateSalary() {
        return hoursWorked*hourlyRate;
    }
}
class  Payroll{
    private ArrayList<Employee> employessList;
    public Payroll(){
        employessList = new ArrayList<>();
    }
    public  void addEmployee(Employee employee){
        employessList.add(employee);
    }
    public void removeEmployee(int id) {
        Employee removeEmployee = null;
        for (Employee employee : employessList) {
            if (employee.getId() == id) {
                removeEmployee = employee;
                break;
            }
        }
        if (removeEmployee != null) {
            employessList.remove(removeEmployee);
        }
    }
        public void displayEmployee(){
            for (Employee employee : employessList){
                System.out.println(employee);
            }

        }


}
public class Main {
    public static void main(String[] args) {
Payroll payroll = new Payroll();
FullTimeEmployee emp1 = new FullTimeEmployee("Vikas",1,85000);
PartEmployee partEmp1 = new PartEmployee("jay",1,8,500);
payroll.addEmployee(emp1);
payroll.addEmployee(partEmp1);
        System.out.println();
        payroll.displayEmployee();
        System.out.println("Removing Employee - ");
        payroll.removeEmployee(2);
        payroll.displayEmployee();
    }
}
