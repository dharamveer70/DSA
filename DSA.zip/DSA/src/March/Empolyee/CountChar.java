package March.Empolyee;

public class CountChar {
    public static void main(String[] args) {
        String input = "VVVVTTTTMMM";
        long V_count = input.chars().filter( c-> c=='V').count();
        long T_count = input.chars().filter(c->c =='T').count();
        long M_count = input.chars().filter(c->c =='M').count();
        System.out.println("Number of V "+V_count);
        System.out.println("Number of T "+T_count);
        System.out.println("Number of M "+M_count);

    }
}
