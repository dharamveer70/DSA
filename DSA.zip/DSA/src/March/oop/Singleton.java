package March.oop;

public class Singleton {
    private static Singleton instance;
    //1.make private static Singleton instance

    private Singleton(){
//2. constructor delacre   as private
    }

    public static Singleton getInstance(){
        if(instance == null){
            instance = new Singleton();
        }
        return instance;
    }


}
