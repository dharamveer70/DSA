package March.oop;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Wrapper {
    public static void main(String[] args) {
        int []pri = {1,5,8,9,6,3,6,4,5};

        Integer [] IntegerPri = new Integer[pri.length];

        // Converting int[] to Integer[]
        for (int i = 0; i < pri.length; i++) {
            IntegerPri[i] = pri[i];
        }

        Stream<Integer>   kl = Stream.of(IntegerPri);
        List<Integer> distinctList =  kl.distinct().collect(Collectors.toList());
        System.out.println("Distinct elements: "+distinctList);

    }
}
