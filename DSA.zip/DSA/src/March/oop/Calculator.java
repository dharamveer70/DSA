package March.oop;
import java.util.Scanner;
public class Calculator {
    public int add(int a,int b){
         return a+b;
     }
     public int min(int a,int b){
         return a-b;
     }
     public int multi(int a,int b){
         return a*b;
     }
     public int divide(int a,int b){
         return a/b;
     }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
         Calculator cal = new Calculator();
         Scanner sc = new Scanner(System.in);
        System.out.println("Write Num 1 ");
        int num1 = sc.nextInt();
        System.out.println("Write Num 2 ");
        int num2 = sc.nextInt();
        System.out.println("Choose Operation:");
        System.out.println("1. Add");
        System.out.println("2. Subtract");
        System.out.println("3. Multiply");
        System.out.println("4. Divide");
        int choice = sc.nextInt();
        int result ;
        switch(choice){
            case 1:
                result = cal.add(num1,num2);
                System.out.println("Result : "+result);
                break;
            case 2:
                result = cal.min(num1,num2);
                System.out.println("Result : "+result);
                break;
            case 3:
                result = cal.multi(num1,num2);
                System.out.println("Result : "+result);
                break;
            case 4:
                result = cal.divide(num1,num2);
                System.out.println("Result : "+result);
                break;
            case 5:
                result = num1+num2;
                System.out.println("Here is sorted Order just "+result);
            default:
                System.out.println("Invalid Choice ");
        }
        scanner.close();
     }
 }