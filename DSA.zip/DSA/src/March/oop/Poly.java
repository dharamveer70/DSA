package March.oop;

public class Poly {
    public int number(int a ,int b,int c){
        return c = a+b;
    }
    public static void main(String[] args) {
        System.out.println();
    }
    class child extends Poly {
        @Override
            public int number(int a, int b, int c) {
                return super.number(a, b, c);
            }public static void main(String[] args) {
                Poly p = new Poly();

                System.out.println(p.number(8,12 ,0));
            }
        }

}
