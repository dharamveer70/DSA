package sunday_8;

import java.util.Scanner;

public class L_sunday {

    public  int add (int a,int b){
        return a+b;
    }


    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter two numbers:");
        double num1 = scanner.nextDouble();
        double num2 = scanner.nextDouble();

        System.out.println("Select operation: ");
        System.out.println("1. Addition (+)");
        System.out.println("2. Subtraction (-)");
        System.out.println("3. Multiplication (*)");
        System.out.println("4. Division (/)");
        int operations = scanner.nextInt();

        double result = 0;

        switch (operations){
            case 1:
               result =num1+num2 ;
               break;
            case 2:
                if (num1>num2){
                    result =num1-num2;
                }else
                    result = num2 - num1;

                //result = num1-num2;
                break;
            case 3:
                result = num1*num2;
            case 4:
                if (num2 != 0) {
                    result = num1 / num2;
                } else {
                    System.out.println("Error! Division by zero.");
                    return;
                }
                System.out.println("Result: " + result);

        }        System.out.println("Result: " + result);

    }}
