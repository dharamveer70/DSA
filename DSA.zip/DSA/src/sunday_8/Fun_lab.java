package sunday_8;
@FunctionalInterface
public interface Fun_lab  {
    public void add();


    default int plus(){
        return 8;
    }
    public static String  Fin(){
        return "";
    }

    interface A {
        static void sayHello(){
            System.out.println("Hello I Think");
        };
    }
    class B implements A{
        public static void main(String[] args) {
            A.sayHello();
        }

    }
}
