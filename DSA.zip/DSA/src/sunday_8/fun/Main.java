package sunday_8.fun;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main implements Runnable {
    public static void main(String[] args) {
        EmpEn emp = () ->"Software Engineer";
        System.out.println(emp.getDepartment());
        Main m1 = new Main();
      //  m1.run();
        List<Integer> list = new ArrayList<>();
        list.add(12);
        list.add(11);
        list.add(10);
        list.add(13);
        list.add(19);
        Collections.sort(list,(a, b)-> b-a);
        System.out.println(list);
    }

    @Override
    public void run() {
        for(int i = 0;i <= 5;i++){
            System.out.println("Hello ");
        }
    }
}
