package sunday_8.fun;

public interface EmpEn {
    public String getDepartment();
}
