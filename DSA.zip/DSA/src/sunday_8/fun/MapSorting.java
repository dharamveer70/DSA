package sunday_8.fun;

import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.function.Predicate;

public class MapSorting {
    public static void main(String[] args) {
        Map<Integer,String>  map = new TreeMap<>();
        map.put(2,"abc");
        map.put(3,"xyz");
        map.put(4,"ab");
        map.put(1,"aab");
       // System.out.println(" Order :"+map);

        //Map<Integer,String>  map2 = new TreeMap<>((a,b)->b-a);
       // map2.put(2,"abc");
       // map2.put(3,"xyz");
       // map2.put(4,"ab");
        //map2.put(1,"aab");
        //System.out.println("Before Manual Storing Order :"+map2);

        Predicate<String>  P_string = x -> x.charAt(0) =='d';
        System.out.println(P_string.test("haramVeer"));

        Optional<String>  name = Optional.of("Dharamveer");
        System.out.println(name.isPresent());


    }
}
