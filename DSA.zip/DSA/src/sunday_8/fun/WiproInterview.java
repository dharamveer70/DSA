package sunday_8.fun;

public class WiproInterview {
    public static void main(String[] args) {
        String a = " Hello";
       a = a.concat(" there");
        System.out.println(a);

    }
}
