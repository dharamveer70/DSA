package sunday_8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Inter {
    public static void main(String[] args) {
      //  List<Integer>  number = Arrays.asList(1,5,16,8,1,9,11,4);
         //  Collections.sort(list);
//      List<Integer> list2=  list.stream().sorted((a,b)->b-a).collect(Collectors.toList());
//        System.out.println(list2);
       // int list_1 =
    String name = "Dharamveer";

    //double a_list = name.chars().equals("a")
        int []  number = {1,8,7,4,5,2,6,2,2};

        long number_a = Arrays.stream(number).boxed().filter(a->a =='2').count();
        System.out.println(number_a);



    }
}
