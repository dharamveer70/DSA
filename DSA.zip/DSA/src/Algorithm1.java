public class Algorithm1 {
    public static void main(String[] args) {


    }
        //  System.out.println("Hello ");
        public static void findDuplicate ( int[] id){
            System.out.println("Find Student Id ");
            for (int i = 0; i < id.length; i++) {
                for (int j = i + 1; j < id.length; j++) {
                    if (id[i] == id[j]) {
                        System.out.println(id[i] + " ");
                        break;
                    }
                }
            }
        }
    }