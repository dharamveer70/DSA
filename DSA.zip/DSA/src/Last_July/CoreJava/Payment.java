package Last_July.CoreJava;

public interface Payment {
    default void addCoupon(){
        System.out.println("add 5 rs Discount Coupon ");
    }
    static void funCoupon(){
        System.out.println("Add Five Rs Coupon ");
    }
     void parking();
}
