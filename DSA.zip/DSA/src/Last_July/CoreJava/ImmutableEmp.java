package Last_July.CoreJava;

import BE_A_STAR.Immutable;

public final class ImmutableEmp {

    private final String  name;
    private final String address;


    public ImmutableEmp(String name ,String address){
        this.name=name;
        this.address=address;
    }

    public String getName(String name ){
        return name;
    }
    public String getAddress(String address){
        return address;
    }

    @Override
    public String toString() {
        return "ImmutableEmp{" +
                "name='" + name + '\'' +
                ", address='" + address + '\'' +
                '}';
    }

    public static void main(String[] args) {
        ImmutableEmp emp = new ImmutableEmp("Dharamveer","Ahmedabad");
        System.out.println(emp);
     //   emp.name = "Jaideep";
    }




}
