package Last_July.CoreJava;

public class StringObject {
    public static void main(String[] args) {
        String s1 = new String("javatechie");
        // line number 5 is created  - 1 Object -> new keyword in heap memory
        // Second object is 2 in scp Literal
        String s2 = new String("javatechie"); //total 2 object are created
        String s3 ="javatechie";
        s3.concat("Java");
        System.out.println(s3);
        //it's already Created in SCP So it's not Created
        System.out.println(s1==s2);      // false
        System.out.println(s1.equals(s2)); // true

        System.out.println(s1.intern().hashCode());
        System.out.println(s3.intern().hashCode());






    }
}
