package Last_July.CoreJava;

public class ExceptionChild implements  Payment{


    @Override
    public void addCoupon() {
        System.out.println("Its For You only sweetie Pie ");
        Payment.super.addCoupon();
    }

    @Override
    public void parking() {

        System.out.println("Free for every One ");
    }


    public static void main(String[] args) {
        ExceptionChild child = new ExceptionChild();
        child.addCoupon();
        child.parking();
        Payment.funCoupon();
    }
}
