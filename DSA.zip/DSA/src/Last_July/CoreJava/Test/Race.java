package Last_July.CoreJava.Test;

import java.util.ArrayList;
import java.util.List;

public class Race {
    private int totalTracks;
    private int trackLength;
    private List<Participant> participants;

    public Race(int totalTracks, int trackLength) {
        this.totalTracks = totalTracks;
        this.trackLength = trackLength;
        this.participants = new ArrayList<>();
    }
    public void addParticipant(String name, int speed, int lengthCapacity) {
        Participant participant = new Participant(name, speed, lengthCapacity);
        participants.add(participant);
    }
    // Method to determine the winner based on speed
    public Participant determineWinner() {
        Participant winner = participants.get(0);
        for (Participant participant : participants) {
            if (participant.getSpeed() > winner.getSpeed()) {
                winner = participant;
            }
        }
        return winner;
    }
    // Method to determine the loser based on length capacity
    public Participant determineLoser() {
        Participant loser = participants.get(0);
        for (Participant participant : participants) {
            if (participant.getLengthCapacity() < loser.getLengthCapacity()) {
                loser = participant;
            }
        }
        return loser;
    }

}
