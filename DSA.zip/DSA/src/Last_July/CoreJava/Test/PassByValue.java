package Last_July.CoreJava.Test;

public class PassByValue {
    public int getMarks() {
        return marks;
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }

    private int marks;

    public PassByValue(int marks) {
        this.marks = marks;
    }

    public static void main(String[] args) {
        PassByValue  by = new PassByValue(10);
        System.out.println(by.marks);
        increaseMark(by);


        

    }

    private static void increaseMark(PassByValue by) {
    }



}
