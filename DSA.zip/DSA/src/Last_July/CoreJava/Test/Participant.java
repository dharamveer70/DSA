package Last_July.CoreJava.Test;

public class Participant {
    private String name;
    private int speed;
    private int lengthCapacity;

    public Participant(String name, int speed, int lengthCapacity) {
        this.name = name;
        this.speed = speed;
        this.lengthCapacity = lengthCapacity;
    }



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getLengthCapacity() {
        return lengthCapacity;
    }

    public void setLengthCapacity(int lengthCapacity) {
        this.lengthCapacity = lengthCapacity;
    }



}
