package Last_July.CoreJava.Test;

public class Source {
    public static void main(String[] args) {
        Race race = new Race(1, 1000); // Example with 1 track of length 1000

        // Adding participants
        race.addParticipant("Ravi", 90, 300);
        race.addParticipant("Sara", 19, 250);
        race.addParticipant("Mike", 12, 350);

        // Determining winner and loser
        Participant winner = race.determineWinner();
        Participant loser = race.determineLoser();

         System.out.println("Winner: " + winner.getName());
        System.out.println("Loser: " + loser.getName());

    }
}
