package Last_July.CoreJava;

public  abstract  class ExceptionHierarchy {

    public static void main(String[] args) {
        try{
            System.out.println(10/2);
        }catch ( ArithmeticException ex){
            System.out.println("Exception----"+ex.getMessage());
        }catch (Exception ex1){
            System.out.println("Arithmetic Exceptions "+ex1);
        }
        finally {
            System.out.println("Here Your Are Aging ");
        }


    }




}
