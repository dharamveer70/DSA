package Last_July.CoreJava;

public class CreateException extends Exception{

    public CreateException(String message){
         super(message);
        System.out.println("Create By Own Exceptions IN Class ");
    }
    class Test {

       // public static void main(String[] args) {
            public  void order(int OrderId) throws CreateException {
                if(OrderId !=1){
                    throw new CreateException("Jab"+OrderId);

                }
            }        }


}
