package Last_July;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FindOut2way {
    public static void main(String[] args) {


        String name = "DharamveerSinghRathore";

        // Using Java 8 streams to find duplicate characters
        List<String> duplicates = new ArrayList<>();
        Set<Character> set = new HashSet<>();

        for (char c : name.toCharArray()) {
            if (!set.add(c)) { // If character already exists in set, it's a duplicate
                duplicates.add(String.valueOf(c));
            }
        }

        System.out.println(duplicates);
    }
}