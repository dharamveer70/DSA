package Last_July.Stream;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StreamTwo {
    public static void main(String[] args) {
        List<Integer> sorted = Arrays.asList(12,5,8,96,3,1,8);
        List<Integer> now1 = sorted.stream().sorted((a,b)->(a<b)?1:(a>b)?-1:0).toList();
        //(a,b)->a.compareTo(b))
     //   System.out.println(now1);
        List<Integer> now = sorted.stream().sorted(Comparator.reverseOrder()).toList();
       //// System.out.println(now);
         List<String> str = Arrays.asList("A","AA","Just","ILOVEYOUASTHA","NNN","MMMM");


        List<String> sortedString = str.stream()
                .sorted(Comparator.comparingInt(String::length))
                .collect(Collectors.toList());
        System.out.println(sortedString);

         str.stream().forEach(s -> System.out.println("Length Of "+s+" is"+s.length()));
        System.out.println(str);
         // Arrays.stream(str).forEach(s -> System.out.println("Length of '" + s + "' is: " + s.length()));


    }
}
