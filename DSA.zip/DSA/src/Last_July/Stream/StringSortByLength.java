package Last_July.Stream;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class StringSortByLength {
    public static void main(String[] args) {
        List<String> str = Arrays.asList("A", "AA", "Just", "I_LOVE_YOU", "NNN", "MMMM");

        List<String> sortedString = str.stream()
                .sorted(Comparator.comparingInt(String::length))
                .collect(Collectors.toList());
        System.out.println(sortedString);
    }
}
