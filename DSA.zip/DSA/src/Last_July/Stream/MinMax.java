package Last_July.Stream;

import java.lang.reflect.Array;
import java.util.*;
import java.util.stream.Stream;

public class MinMax {
    public static void main(String[] args) {
        Stream<?> item = Stream.of(8,9,6,44,"cc","kli",8);
        int number = (int) item.count();
       // System.out.println(number);
       // item.forEach(System.out::println);

        List<Integer> salary = Arrays.asList(7,8,9,6,1,5,6,19,12);

        Set<Integer> nu = new HashSet<>();
        nu.add(4);
        nu.add(8);
        nu.add(null);
        nu.add(null);
        nu.add(null);
        System.out.println(nu);


        int max  = salary.stream().sorted(Comparator.reverseOrder()).skip(1).findFirst().get();

        // = salary.stream().max(Integer::compareTo).get();
      //  System.out.println(max);

    //    System.out.println(max);

    }
}
