package Last_July.Stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamOne {
    public static void main(String[] args) {
        List<Integer> number = Arrays.asList(12,5,8,9,6,39,36,45);
       List<Integer> List = number.stream().filter(m->m%2==0).toList();
      //  System.out.println(List);
        List<Integer> multi = number.stream().map(m->m*2).toList();
       // System.out.println(multi);
        //Check Out Passed Students only

        List<Integer>  passed = number.stream().filter(i->i>35).toList();
        System.out.println(passed);
        //count Passed Student number
        Long count = number.stream().filter(i->i>35).count();
        System.out.println(count);

        List<Integer>  ByGraced = number.stream().filter(i->i<35).map(k->k+5).toList();

        System.out.println(ByGraced);

    }
}
