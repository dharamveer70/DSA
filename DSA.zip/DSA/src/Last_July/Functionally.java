package Last_July;
@FunctionalInterface
public interface Functionally {

    int add(int a, int b);

    default String name(){
        return "Ram";
    }
    static String city(){
        return "Jaipur";
    }
}
