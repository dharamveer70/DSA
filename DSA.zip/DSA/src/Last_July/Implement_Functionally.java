package Last_July;

public class Implement_Functionally {


    public static void main(String[] args) {
        Functionally fun = (int a , int b )-> a+b;
        System.out.println(fun.add(7,8));
        System.out.println( Functionally.city());
        String name = fun.name();
        System.out.println(name);


    }



}
