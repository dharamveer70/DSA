package Last_July;

public class ThrowThrows {
}
