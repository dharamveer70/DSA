package Last_July;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class countEachCharacters {
    public static void main(String[] args) {
        String name = "DharamveerSinghRathore";
        Map<String,Long> map  = Arrays.stream(name.split("")).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
       System.out.println(map);

        //Start With One Just Like 14 ,18
        int [] number = {14,5,18,9,6,3,7,2,89};
        List<String>  StartWithOne = Arrays.stream(number).boxed().map(s->s+" ").filter(s->s.startsWith("1")).collect(Collectors.toList());

      // System.out.println(StartWithOne);

        //String Join method In java \

        List<String> str1 = Arrays.asList("1","89","9","8","6");
        String result = String.join("-",str1);
       System.out.println(result);

        //Skip & Limit  Example (2-9)

      //  IntStream.rangeClosed(1,10).skip(1).limit(8).forEach(System.out::println);






    }
}

