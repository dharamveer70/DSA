package Last_July;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class SecondFindMaxNum {
    public static void main(String[] args) {
        int numb[] = {1,25,8,9,6,3,4,2,78};

       List<Integer> Revers = Arrays.stream(numb).boxed().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
       // System.out.println(Revers);
        List<Integer> Defult = Arrays.stream(numb).boxed().collect(Collectors.toList());
     //   System.out.println(Defult);

        Integer integer = Arrays.stream(numb).boxed().sorted().skip(1).findFirst().get();
        System.out.println(integer);
        Integer integer1 = Arrays.stream(numb).boxed().sorted(Comparator.reverseOrder()).skip(1).findFirst().get();
        System.out.println(integer1);
    }
}
