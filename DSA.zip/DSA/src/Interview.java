
import java.util.Arrays;
import java.util.stream.Collectors;

public class Interview {
    public static void main(String[] args) {


            String str = "THAT IS A SENTENCE";
            String name = "Dharamveer";

        System.out.println(name.split("d",3));

            String reversed = Arrays.stream(str.split("\\s+"))
                    .map(Interview ::reverseString)
                    .collect(Collectors.joining(" "));
            System.out.println(reversed);
        }

        public static String reverseString (String s) {

        return new StringBuilder(s).reverse().toString();
        }
        }

