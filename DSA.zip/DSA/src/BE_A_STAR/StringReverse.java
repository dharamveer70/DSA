package BE_A_STAR;

import java.util.HashMap;
import java.util.Map;

public class StringReverse {

    //string in reverse name

    public static void main(String[] args) {
        String name = "Jaipur";
        String revers = "";
        for (int i = name.length()-1;i>=0;i--){
            revers = revers+name.charAt(i);
        }
        System.out.println(revers);


        HashMap<Integer,String> map = new HashMap<>();
        map.put(1,"abs");
        map.put(7,"abs");
        map.put(9,"abs");
        map.put(6,"abs");
        map.put(4,"abs");

        map.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(System.out::println);
        map.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);






    //    System.out.println(revers);

    }
}
