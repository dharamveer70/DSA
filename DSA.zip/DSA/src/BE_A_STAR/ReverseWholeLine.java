package BE_A_STAR;

import java.util.Arrays;
import java.util.stream.Collectors;

//ReverseWholeLine
public class ReverseWholeLine {
    public static void main(String[] args) {
        String Line = "THAT IS A SENTENCE";

        String reversed = Arrays.stream(Line.split(" ")).map(ReverseWholeLine::reverseString).
                collect(Collectors.joining(" "));

        System.out.println(reversed +"ITS 2nd Side Of the  ");

    //    reverseString(Line);

     //   System.out.println(reverseString(Line));
    }
   public static String reverseString(String s){

        return new StringBuilder(s).reverse().toString();
   }

}
