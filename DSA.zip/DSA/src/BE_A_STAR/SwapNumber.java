package BE_A_STAR;

public class SwapNumber {
    public static void main(String[] args) {
        int a = 27 ;
        int b = 23 ;
        a = a+b  ;
        b = a-b;
        a = a-b ;
        System.out.println(a);
        System.out.println(b);
     }
}
