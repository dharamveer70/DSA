package BE_A_STAR;

public final class  Immutable {
    private final  String name ;

    private  final int number;

    public String getName() {
        return name;
    }

    public int getNumber() {
        return number;
    }


// comes
    private Immutable(String name,int number){
        this.name=name;
        this.number =number;
    }

}
