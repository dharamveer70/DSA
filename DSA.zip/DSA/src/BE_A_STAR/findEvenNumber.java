package BE_A_STAR;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class findEvenNumber {
    public static void main(String[] args) {
        List<Integer> number = List.of(1,5,6,9,6,3,8,6,6,6,6,8,1,4,7);
        number.stream().forEach(i-> System.out.println(i));

List<Integer>  decs = number.stream().distinct().collect(Collectors.toList());
        System.out.println("DESC"+decs);

        Integer min = number.stream().max(Integer::compareTo).get();//min(Integer::compareTo)
//        System.out.println(min);

        List<Integer> desc = number.stream().sorted(Comparator.reverseOrder()).toList();
        //Comparator.reverseOrder()).toList();
        //(a, b) -> -a.compareTo(b))

        // System.out.println(desc);

        List<Integer> even = number.stream().filter(n->n%2==0).toList();
       // System.out.println(even);

        List<Integer> map2 = number.stream().map(n->n*2).toList();
       // System.out.println(map2);


        List<Integer> pass = number.stream().filter(n->n>=6).toList();
        long count = number.stream().filter(n->n>=6).count();
       // System.out.println(count);
       // System.out.println(pass);

        List<Integer> fail = number.stream().filter(n->n<=6).toList();
      //  System.out.println(fail.stream().map(n->n+10).toList());


        List<Integer> Sorted = number.stream().sorted().toList();
       // System.out.println(Sorted);








    }
}
