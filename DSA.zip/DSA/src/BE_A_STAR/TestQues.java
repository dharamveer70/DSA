package BE_A_STAR;

import java.util.Arrays;
import java.util.stream.Collectors;

public class TestQues {
    public static void main(String[] args) {
        String name ="Dharamveer Singh Rathore";
        String r = Arrays.stream(name.split(" ")).map(TestQues::revers).collect(Collectors.joining(" "));
        System.out.println(r);
    }
    public static  String revers(String s){
        return new StringBuilder(s).reverse().toString();
    }
}
