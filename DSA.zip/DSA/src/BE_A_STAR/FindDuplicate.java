package BE_A_STAR;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FindDuplicate {
    public static void main(String[] args) {

        List<String>  names = List.of("Ravi","Jai","Dev","Jai","Ravi");

        Map<String,Long>  nameList =  names.stream().collect(Collectors.groupingBy(n->n,Collectors.counting()));


    nameList.entrySet().stream().filter(entry->entry.getValue()>1).forEach(entry->
            System.out.println("Duplicate - entry "+entry.getValue()));


       // number.stream().forEach(n->n  );

        System.out.println(nameList);
//
//
//        List<Integer>  number = List.of(1,8,9,62,5,8,74,11,2,5,78);
//
//        Map<Integer,Long> counts  = number.stream().collect(Collectors.groupingBy(n->n,Collectors.counting()));
//
//        counts.entrySet().stream()
//                .filter(entry -> entry.getValue() > 1)
//                .forEach(entry -> System.out.println("Duplicate element: " + entry.getKey()));
//
//        System.out.println(counts);


    }
}
