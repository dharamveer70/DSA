package BE_A_STAR;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Characters {

        public static void main(String[] args) {
            String str = "BeetBtteraba aba";
           Map<String, Long> charCount = Arrays.stream(str.split("")).
                   collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
         //   System.out.println(charCount);
        charCount.entrySet().stream().filter(i->i.getValue()>1).forEach(p-> System.out.println("count-"+p));
    }

}
