package BE_A_STAR.August.Java8;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class ConsumerInterface {



    public static void main(String[] args) {
        //Consumer Interface Example
        Consumer<Integer>   consumer = (t)-> System.out.println("hey There Is "+t+" rs ");
        consumer.accept(10);
        List<Integer>  list =  List.of(14,8,5,6,6,8,5,4,6,89);
      //  list.stream().forEach(consumer);
       // list.stream().forEach(i-> System.out.println("heye There Is "+i+" RS"));

        //Predicate Interface Example Check Only conditional return only Boolean
        //Filter method
        Predicate<Integer>  pri = (t)-> t % 2 == 0;
       // System.out.println(pri.test(9));
    //    list.stream().filter(i->i%2==0).distinct().forEach(System.out::println);
        //Compare Method

        int array[] = {2,5,86,8,4,5};
        Arrays.stream(array).boxed().distinct().sorted((a,b)->b-a).forEach(System.out::println);

     List<Integer> list1 =
        list.stream().sorted((a,b)->b-a).distinct().collect(Collectors.toList());

     //just image we have Class Employee, and we want to be Sorted base on Salary
        //  Employee.stream().
      //  System.out.println(list1);


    }

        }
