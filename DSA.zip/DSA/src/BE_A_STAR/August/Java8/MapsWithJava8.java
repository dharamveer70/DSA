package BE_A_STAR.August.Java8;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

public class MapsWithJava8 {
    public static void main(String[] args) {

        Map<String,Integer>  map = new HashMap<>();
        map.put("abs",5);
        map.put("zbs",3);
        map.put("cbs",4);
        map.put("mbs",1);
        map.put("bs",2);

        map.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(System.out::println);
     // map.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.reverseOrder())).forEach(System.out::println);
   // map.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.comparing(Employee::getSalary))).forEach(System.out::println);

  //  IntStream.rangeClosed(1,555).map(i->i*3).filter(i->i<1000).forEach(System.out::println);


        List<Integer>  list  = List.of(5,8,9,6,4,8,10);
//        int sum=0;
//        for (int num:list){
//            sum=sum+num;
//        }
//        System.out.println(sum);

        int sum2 =    list.stream().mapToInt(i->i).sum();
        //list.stream().reduce(Integer::sum);

        //System.out.println(sum2);

        //IF WE WANT To MULTIPLE

//        Integer multi = list.stream().reduce(1,(a,b)->a*b);
//        System.out.println(multi);
//
//        Integer max = list.stream().reduce(Integer ::max ).get();
//        System.out.println(max);
//
//        Integer min = list.stream().reduce(Integer ::min ).get();
//        System.out.println(min);


        List<String> name = List.of("Dharamveer","Singh","Arun","Arun");
        String s2 = name.stream().reduce((a,b)->a.length()<b.length()?a:b).get();
        System.out.println(s2);






    }

}
