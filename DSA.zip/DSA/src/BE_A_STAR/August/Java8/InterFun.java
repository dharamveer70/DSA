package BE_A_STAR.August.Java8;
@FunctionalInterface
public interface InterFun {

    public abstract Integer sum(int a,int b);


    default String firstName(){
        return "Hello There ";
    }

    static String  m1(){
        return"m1 method in java ";
    }

    default void honk() {
        System.out.println("Honking!");
    }

    // Static method (with a body)
    static void displayInfo() {
        System.out.println("This is a vehicle interface.");
    }

    // Constants (public, static, and final by default)
    int MAX_SPEED = 120;


}
