package BE_A_STAR.August.Java8;

import java.util.stream.IntStream;

public class MyFunctionalInterface implements InterFun {
    public static void main(String[] args) {

//        MyFunctionalInterface my = new MyFunctionalInterface();
//        System.out.println(my.firstName());
//        my.honk();
//        InterFun.displayInfo();
//        System.out.println(InterFun.m1());
//        InterFun adder = (a, b) -> a + b;
//        Integer result = adder.sum(5, 3);
//        System.out.println("Sum: " + result);


//        for (int i = 0; i < 1000; i += 3) {
//            System.out.println(i);
//        }

        IntStream.rangeClosed(1, 333)
                .boxed()
                .map(m -> m * 3)
                .filter(i -> i < 1000)
                .forEach(System.out::println);



    }
    @Override
    public Integer sum(int a, int b) {
        return null;
    }
    @Override
    public String firstName() {
        return "Hello Hero ";
    }
    @Override
    public void honk() {
        InterFun.super.honk();
    }
}
