package BE_A_STAR;

import java.util.*;
import java.util.stream.Stream;

public class Arrays25 {
    public static void main(String[] args) {
        List<Integer> number = List.of(12, 36, 8, 9, 5, 6, 5, 85, 8, 5, 8, 9, 6, 2, 85);
        //find First Element Of list
        //int findFirst =number.stream().findFirst().get();
        //  System.out.println(findFirst);
        //Max and Min
        // int min = number.stream().distinct().min(Integer::compareTo).get();
        //Check Count Number of List
        //    System.out.println(number.stream().count());

        //find Out ood and Even Number from List
        //  number.stream().filter(i->i%2==0).forEach(System.out::println);  //EVEN NUMBER
        // number.stream().filter(i->i%2!=0).forEach(System.out::println);  //ODD NUMBER
        //Find number start From 8
        // number.stream().filter(i->i.toString().startsWith("8")).forEach(System.out::println);
        //just find out how many duplicate number in List
   //   Set<Integer> num = new HashSet<>();
   //    number.stream().filter(i -> !num.add(i)).forEach(System.out::println);

        // number.stream().sorted(Comparator.reverseOrder()).forEach(i-> System.out.println(i));

           number.stream().map(n->n*n).filter(n->n<50).forEach(System.out::println);



     //   Map<String,Long> map = name.stream().collect(Collectors.groupingBy(s->s,Collectors.counting()));
//        map.entrySet().stream().filter(m->m.getValue()>1).forEach(m-> System.out.println(" Key Is Here "+m.getKey()+
//                " Value Is Here "+m.getValue()));


        // name.stream().map(i->i.toUpperCase()).forEach(System.out::println);

//        int ar[] = {1, 25, 8, 9, 6, 85, 9, 6};
//        int max = 0;
//        for(int i =0;i<ar.length-1;i++){
//            if(max<ar[i]){
//                max=ar[i];
//            }
//        }
//            System.out.println(max);


       // int nu = 95;
        // Arrays.stream(ar).filter(n->n==78).forEach(System.out::println);


        //  Arrays.stream(ar).min().ifPresent(System.out::println);
        //Print Random Number and SET any Limit

        Random r1 = new Random();
        Stream.generate(r1::nextInt).limit(10).filter(i -> i < 50).forEach(System.out::println);

//        Stream.generate(() -> r1.nextInt(100))
//                .limit(100)
//                .filter(i -> i < 50)
//                .forEach(System.out::println);

      //  LocalDateTime date = LocalDateTime.now();
        //  System.out.println(date);
        //dd-mm-yyyy
      //  DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-mm-yyyy");
        //   System.out.println(formatter.format(date));
       List<String> name = List.of("dev", "Dharamveer", "jai", "tum", "jab", "jab");
//
//Employee em = new Employee("ravi",2500);
//        Employee em2 = new Employee("dev",3500);
//        List<Employee> add= new ArrayList<>();
//        add.add(em);
//        add.add(em2);
//        System.out.println(add.stream().sorted());



    }
    }
