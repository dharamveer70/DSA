package BE_A_STAR;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public class FindLongestword {
    public static void main(String[] args) {
        String str [] = {"Java","Spring","boot","SpringBoot","Microservice"};

      //  Arrays.stream(str).forEach(i-> System.out.println(i+" -- "+i.length()));

        List<String> sre = List.of("Java","Spring","boot","SpringBoot","Microservice");

        String longestWord = Arrays.stream(str)
                .max((s1, s2) -> Integer.compare(s1.length(), s2.length()))
                .orElse("No words available");

        //System.out.println("The longest word is: " + longestWord);


      sre.stream().forEach(i-> System.out.println(i+"   "+i.length()));
//        sre.stream()
//                .skip(1) // Skip the first element
//                .limit(1) // Limit to one element
//                .forEach(i -> System.out.println(i + " length is " + i.length()));

       // Arrays.stream(str).forEach(i-> System.out.println(i+"- length-is - "+i.length()));

//        List<Integer> number = Arrays.asList(1,2,8,9,6,1,5,88,9,6,9);
//     int sorted = number.stream().sorted().max(Integer::compareTo).stream().skip(1).findAny().get();
//
//       System.out.println(sorted);













//       // Map<String,Long> map = Arrays.stream
//
//        String longest = Arrays.stream(str).reduce((word1,word2) -> word1.length() >word2.length()? word1:word2).get();
//       // System.out.println(longest);
//
//        for (String s : str){
//            int length = s.length();
//           // System.out.println("Length Of -::"+s+" is "+length);
//        }
//        Arrays.stream(str)
//                .forEach(s -> System.out.println("Length of '" + s + "' is: " + s.length()));


    }
}
