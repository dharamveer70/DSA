package BE_A_STAR;

import java.util.Scanner;

public class Throw_Throws {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int age =  sc.nextInt();
        try {


        if(age<18){
            System.out.println("Your must Be Vote ");
            throw new IllegalArgumentException("Age IS less Than ");
        }
            System.out.println("Age"+age);
        }catch (IllegalArgumentException e){
            System.err.println(e.getMessage());
        }

    }

}
