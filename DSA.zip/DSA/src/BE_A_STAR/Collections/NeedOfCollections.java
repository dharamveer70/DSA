package BE_A_STAR.Collections;

import java.util.*;
import java.util.stream.Collectors;

public class NeedOfCollections {
    public static void main(String[] args) {
        List<Object> str1 = new ArrayList<Object>();
        str1.add("Jai");
        str1.add(50);
        //why we need Collections in java
        //Limited of Arrays
        //array Store Only one Type Of data its working for Homogeneous Not for  heterogeneous
        // Ready Made Api Supports Is Not Available In Arrays


        Student [] s1 = new Student[10];
        Student[] s2 = new Student[23];
        Student [] s3 = new Student[25];

        ArrayList<Integer> l1  = new ArrayList<>(List.of(1,5,8,9,6,90));
        ArrayList<Integer>  l2 = new ArrayList<>();
        Collections.addAll(l2,58,69,6,9,6,63,1);

        Set<String> str = new HashSet<>();
        str.add("Veer");
        str.add(null);
        System.out.println(str);

       // ArrayList<Integer>  l3 = new ArrayList<>(l2);
       // ArrayList<Integer>  l3 = new ArrayList<>(l2);



    }


class Book{


}

    class Student{

    }
}
