package BE_A_STAR.Collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class HashSET {
    public static void main(String[] args) {
            Set<String> Course = new HashSet<>();
            Course.add("Java");
        Course.add("Spring");
        Course.add("MVC");
        Course.add("PHP");
        Course.add("SpringBoot");
//       System.out.println(Course);
//        for (String c : Course){
//            System.out.println(c);
//        }
//
    Course.stream().forEach(i-> System.out.println(i+" -"+i.length()));
//WHILE LOOP
        Iterator<String>  str =Course.iterator();
        while (str.hasNext()){
            String c1 =  str.next();
            System.out.println(c1);
        }

    }
}
