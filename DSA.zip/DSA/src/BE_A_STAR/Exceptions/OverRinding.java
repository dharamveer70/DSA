package BE_A_STAR.Exceptions;

public class OverRinding {

     String  parents(){
        return "Its From Parents";
    }


    class Cer extends OverRinding{

         String parents() throws ArithmeticException{
             return  "Hello";
         }

        public static void main(String[] args) {
            OverRinding rq = new OverRinding();
            rq.parents();

        }
    }

}
