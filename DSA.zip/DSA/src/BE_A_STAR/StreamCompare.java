package BE_A_STAR;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class StreamCompare {
    public static void main(String[] args) {
        List<String> na = Arrays.asList("A", "SSS", "DEDEED", "KKKK", "LIOPL", "WW");

//        List<String> map = name.stream().forEach(i-> System.out.println(i.length()));
        Comparator<String> c = (a, b) -> {
            int l1 = a.length();
            int l2 = b.length();
            return Integer.compare(l1, l2);
        };
        List<String> str = na.stream().sorted(c).toList();
//        System.out.println(str);

        String str1 = "Dharamveer";
        String str2 = "Dharamveer";
        String str3 = new String( "Dharamveer");
        String str4 = new String("Dharamveer");

        System.out.println(str1==str2);  //ture
        System.out.println(str2==str3); //false
        System.out.println(str1.equals(str2));  //true
        System.out.println(str1.equals(str3));  //ture
        System.out.println(str4==str3);
        System.out.println(str3.equals(str4));









    }


}
