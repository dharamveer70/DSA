package BE_A_STAR;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class FlatMapExp {
    public static void main(String[] args) {

        List<Integer>  number = Arrays.asList(1,5,8,9,6,7,8,5,45,49);
       // number.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);

        List<String> str = Arrays.asList("ram","Shyam","Geeta","Sita");
        str.stream().peek(i-> System.out.println("Original - "+i)).map(String::toUpperCase).forEach(System.out::println);


    }

    public List<Item> getAllItem(List<Order> oders){
        return oders.stream().flatMap(i-> i.getItem().stream()).toList();
    }
}



class Order{

    private List<Item> items;

    public List<Item> getItem(){
        return items;
    }

}

class Item{
    private String name ;
    //5 product i sell and total item 50

    public String getName(){
        return name;
    }
}