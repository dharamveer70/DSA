package BE_A_STAR;

import java.util.Arrays;
import java.util.List;

public class Neo {
    public static void main(String[] args) {
        List<Integer> myList = List.of(10,15,8,49,25,98,32);
        // start 1

        myList.stream().filter(i->i.toString().startsWith("1")).forEach(System.out::println);

    }
}
