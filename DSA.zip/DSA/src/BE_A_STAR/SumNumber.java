package BE_A_STAR;

import java.util.List;
import java.util.stream.Collectors;

public class SumNumber {
    public static void main(String[] args) {
         List<Integer>  number = List.of(12,5,8,6,89,96,2,3,8);
       int sum =  number.stream().reduce(Integer::sum).get();
        System.out.println(sum);
//         List<String> name = List.of("Java","Each","Of","Sum","Java");
//        List<String> num2 = name.stream().filter(m->m.contains("Java")).collect(Collectors.toList());
//         List<Integer> num=   number.stream().filter(m-> m % 2 != 0).collect(Collectors.toList());
//       System.out.println(num2);
//        System.out.println(num);

    }
}
