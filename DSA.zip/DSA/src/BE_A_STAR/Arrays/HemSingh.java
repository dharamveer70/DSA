package BE_A_STAR.Arrays;

public class HemSingh {
    public static void main(String[] args) {
        System.out.println("hello Hem ");
        Cns c1= new Cns(10,20);
        int   area1=c1.getdata();
        System.out.println("THe area of rectangle is: "+area1);
    }
}
class Cns {
    int length,width;
    Cns(int x,int y){
        length=x;
        width=y;
    }
    int getdata(){
        return(length*width);
    }
}
//public class person{
//
//    public static void main(String[] args){
//
//    }
//}
