package BE_A_STAR.Arrays;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ReverseArrays  {
    public static void main(String[] args) {
        int arrays[] = {2,58,9,9,9,9,98,4,1,59};
        List<Integer>  jk = List.of(25,8,9,6,5,8,6,8);


        jk.stream().filter(i->i>50).filter(i->i<100).forEach(System.out::println);

        jk.stream().filter(i->i % 2==0).map(i->i*i*i).forEach(System.out::println);
       List<Integer> li=  Arrays.stream(arrays).boxed().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
       // System.out.println(li);
        Arrays.stream(arrays).boxed().filter(i->i % 2==0).sorted((a,b)->b-a).forEach(System.out::println);


    //    Arrays.stream(arrays).boxed().distinct().forEach(System.out::println);

       // IntStream.rangeClosed(1,333).map(m->m*3).filter(i->i<1000).forEach(System.out::println);

//        for (int i = 1; i <= 333; i++) {
//            int value = i * 3;
//            if (value < 1000) {
//                System.out.println(value);
//            }
//        }

      //Integer num =   Arrays.stream(arrays).boxed().min(Integer::compareTo).get();
       // System.out.println(num);



    }
}
