package BE_A_STAR;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class NameFilter {
    public static void main(String[] args) {
        List<String> names = Arrays.asList("Alice", "Bob", "Anna", "Adam", "Alex");

        List<String> nameStartWith_A_ = names.stream().filter(n->n.startsWith("A")).toList();
        System.out.println(nameStartWith_A_);

    }
}
