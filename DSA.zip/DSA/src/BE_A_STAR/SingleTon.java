package BE_A_STAR;

public class SingleTon {

    private static SingleTon instance;

    // Private constructor prevents instantiation from other classes
    private SingleTon() {}

    // Method to provide access to the single instance
    public static SingleTon getInstance() {
        if (instance == null) {
            instance = new SingleTon();
        }
        return instance;
    }

}
