package BE_A_STAR;

public class deloitte {
    public static void main(String[] args) {
        int operation = 2;
        int number = 10;

        int arr[] = {1,3,5,7};
        //3,5,7,1


        switch (operation){
            case 1:
                    number = number+10;
                    break;
            case 2:
                number = number-4;
            case 3:
                number = number/3;
            case 4:
                number = number*10;
            break;
        }

    }
}
