package BE_A_STAR;

import Last_July.Functionally;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CountEachWord {
    public static void main(String[] args) {
        String name = "DHARAMVEER SINGH RATHORE";

        //Each Count Every Words
        Map<String, Long> map = Arrays.stream(name.split("")).collect((Collectors.
                groupingBy(Function.identity(), Collectors.counting())));
        System.out.println(map);
    }
   // Find Duplicate then WE Use
//
//        map.entrySet().stream().filter(i->i.getValue()>1).forEach(System.out::println);
//            }


    //    charCount.entrySet().stream().filter(i->i.getValue()>1).forEach(p-> System.out.println("count-"+p));


}
