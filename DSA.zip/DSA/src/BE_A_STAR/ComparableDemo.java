package BE_A_STAR;


import java.util.*;
class Employee implements Comparable {
    String name;
    int age;
    Employee(String name, int age) {
        this.name = name;
        this.age = age;
    }
    //overridden compareTo method
    @Override
    public int compareTo(Object o) {
        return this.age - ((Employee) o).age;
    }
}
public class ComparableDemo {
    public static void main(String[] args) {



        String s1 = "tutorialspoint";
        String s2 = "tutorialspoint";
        String s3 = new String ("tutorialspoint");
        System.out.println(s1 == s2);
        System.out.println(s2.equals(s3));



        // CREATION
//        List list = new ArrayList<>();
//        //INSERTION
//        list.add(new Employee("Krishna", 30));
//        list.add(new Employee("Archana", 28));
//        list.add(new Employee("Vineet", 25));
//        list.add(new Employee("Ramesh", 38));
//        list.add(new Employee("Alok", 28));
//     //   System.out.println("Before sorting: ");
//        for (Employee e : list) {
//            System.out.print("[ EMP : age = " + e.age + " ] ");
//        }
//        //SORTING
//        Collections.sort(list);
//        System.out.println("After sorting: ");
//        for (Employee e : list) {
//            System.out.print("[ EMP : age = " + e.age + " ] ");
//        }
    }
}
