package BE_A_STAR;

import java.util.Scanner;

public class PalindromeNumber2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int number = sc.nextInt();

        if (isPalindrome(number)) {
            System.out.println("The number \"" + number + "\" is a palindrome.");
        } else {
            System.out.println("The number \"" + number + "\" is not a palindrome.");
        }

        sc.close(); // Close the scanner
    }

    public static boolean isPalindrome(int number) {
        int reversed = 0;
        int original = number;

        while (number != 0) {
            int digit = number % 10;
            reversed = reversed * 10 + digit;
            number /= 10;
        }
        return original == reversed;
    }
}
