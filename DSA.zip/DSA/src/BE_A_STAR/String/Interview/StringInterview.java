package BE_A_STAR.String.Interview;

import java.util.Arrays;
import java.util.Collections;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class StringInterview {
    public static void main(String[] args) {
        String name = "aaabbacccdd ii";
        //Count Each Charters In String
      Map<String,Long> count = Arrays.stream(name.split("")).collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
        System.out.println(count);




    }
}
