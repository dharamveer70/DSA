package BE_A_STAR;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class PalindromeNumber1 {
    public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter a number: ");
            int number = scanner.nextInt();

            if(isPalindrome(number))
                System.out.println(number + " is a palindrome number.");
            else
                System.out.println(number + " is not a palindrome number.");

            scanner.close();
        }

        // Function to check if a number is palindrome
        public static boolean isPalindrome(int number) {
            int reversed = 0;
            int originalNumber = number;

            while (number != 0) {
                int digit = number % 10;
                reversed = reversed * 10 + digit;
                number /= 10;
            }

            return originalNumber == reversed;
        }
    }
