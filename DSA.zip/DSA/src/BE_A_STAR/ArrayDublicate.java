package BE_A_STAR;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ArrayDublicate {
    public static void main(String[] args) {
        int arr[] = {8,5,6,5,8,6,6,2,9,3};
        List<Integer> number = Arrays.stream(arr).boxed().distinct().toList();

        System.out.println(number);


//        IntStream.rangeClosed(1, 333)  // Generate a stream of integers from 1 to 333
//                .map(n -> n * 3)      // Multiply each integer by 3
//                .filter(num -> num < 1000) // Filter numbers less than 1000
//                .forEach(System.out::println);
    }





}
