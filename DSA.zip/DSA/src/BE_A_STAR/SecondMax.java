package BE_A_STAR;

import java.util.Comparator;
import java.util.List;

public class SecondMax {
    public static void main(String[] args) {
        List<Integer> number = List.of(1,2,8,5,9,6,36,78,99,5,89,101);
        Integer max = number.stream().distinct().sorted(Comparator.reverseOrder()).skip(2).findFirst().orElse(null);
        System.out.println(max);

        Integer min = number.stream().sorted().skip(1).findFirst().orElse(null);
        System.out.println(min);
    }
}
