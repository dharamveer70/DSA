package Eight;



class thread2 extends Thread{

   public void run(){

   }
}


public class Thi extends thread2 {

    public static void main(String[] args) {
        thread2 t2 = new thread2();
        t2.start();
    }

}
