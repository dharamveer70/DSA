package Eight;

import java.util.*;

public class Each {

    public static void main(String[] args) {
        List<Integer>  ML = Arrays.asList(1,5,8,6,3,89);
        Collections.sort(ML);
        ML.forEach(n-> System.out.println(n));
    }
}
