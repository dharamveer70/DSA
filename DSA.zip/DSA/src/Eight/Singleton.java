package Eight;

public class Singleton {
    public static final Singleton s1 = new Singleton();
    private Singleton() {
    }

    public static Singleton instance(){

        return s1;
    }
}
