package Eight;

import java.util.Arrays;
import java.util.Scanner;

public class Magnetic2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input strings S1, S2, and the magnetic letters box string R
        String s1 = scanner.nextLine();
        String s2 = scanner.nextLine();
        String r = scanner.nextLine();

        // Concatenate strings S1 and S2
        String concatenated = s1 + s2;

        // Convert concatenated and magnetic letters box strings to char arrays
        char[] concatenatedChars = concatenated.toCharArray();
        char[] rChars = r.toCharArray();

        // Sort concatenated and magnetic letters box char arrays
        Arrays.sort(concatenatedChars);
        Arrays.sort(rChars);

        // Convert sorted char arrays back to strings
        String sortedConcatenated = new String(concatenatedChars);
        String sortedR = new String(rChars);

        // Check if the sorted concatenated strings and the sorted magnetic letters box string are equal
        if (sortedConcatenated.equals(sortedR)) {
            System.out.println("Yes");
        } else {
            System.out.println("No");
        }

        scanner.close();
    }
}

