package Eight;

import java.util.Scanner;
import java.util.stream.Collectors;

public class MagneticLetterbox {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input strings S1, S2, and the magnetic letters box string R
        String s1 = scanner.nextLine();
        String s2 = scanner.nextLine();
        String r = scanner.nextLine();

        // Concatenate strings S1 and S2
        String concatenated = s1 + s2;

        // Sort concatenated and magnetic letters box strings
        String sortedConcatenated = concatenated.chars()
                .mapToObj(c -> (char) c)
                .sorted()
                .map(String::valueOf)
                .collect(Collectors.joining());
        String sortedR = r.chars()
                .mapToObj(c -> (char) c)
                .sorted()
                .map(String::valueOf)
                .collect(Collectors.joining());

        // Check if the sorted concatenated strings and the sorted magnetic letters box string are equal
        if (sortedConcatenated.equals(sortedR)) {
            System.out.println("Yes");
        }
    }
}
