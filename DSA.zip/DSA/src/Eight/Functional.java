package Eight;

@FunctionalInterface
interface Demo {
    void show();
}
public class Functional   {
    public static void main(String[] args) {
        Demo fun = () -> System.out.println("Here There Is Java Eight ");
       fun.show();
    }

}
