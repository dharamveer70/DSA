package Eight;


public interface Fun {

    int a=2;
    int b =4;

    default int sum(){
        int c= a+b;

        return c;
    }

}
