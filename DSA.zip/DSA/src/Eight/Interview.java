package Eight;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Interview {
//[4:25 PM] Abhishek Kumar | CloudAngles
//aabbccaa -> a2b2c2a2   long V_count = input.chars().filter( c-> c=='V').count();

    public static void main(String[] args) {
     String words =    "aabbccaa";
     long a_count = words.chars().filter(c->c=='a').count();
     long b_count = words.chars().filter(c->c=='b').count();
     long c_count = words.chars().filter( c->c =='c').count();
        System.out.println("A count "+a_count);
        System.out.println("B count "+b_count);
        System.out.println("C count "+c_count);



    }


}
