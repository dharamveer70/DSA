package Eight;

public class FunImpl implements Fun {


    @Override
    public int sum() {
        return 0;
    }
}
