package DSA;

import java.util.Scanner;

public class BookBinarySearch {

    private static int bookBinarySearch(int[] userIDs, int start, int end, int searchValue) {
        if (end < start) {
            return -1;
        }

        int mid = (start + end) / 2;

        if (userIDs[mid] == searchValue) {
            return mid;
        } else if (userIDs[mid] > searchValue) {
            return bookBinarySearch(userIDs, start, mid - 1, searchValue);
        } else {
            return bookBinarySearch(userIDs, mid + 1, end, searchValue);
        }
    }

        public static int search(int[] userIDs, int searchValue) {
        return bookBinarySearch(userIDs, 1, userIDs.length - 1, searchValue);
    }


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int size = scanner.nextInt();
        int searchValue = scanner.nextInt();

        if (size == 0) {
            System.out.println("NOT FOUND");
            return;
        }


        int[] userIDs = new int[size + 1];
        for (int i = 1; i <= size; i++) {
            userIDs[i] = scanner.nextInt();
        }

        int index = search(userIDs, searchValue);


        System.out.println(index == -1 ? "NOT FOUND" : index);

        scanner.close();
    }
}
