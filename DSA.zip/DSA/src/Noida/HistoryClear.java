package Noida;
import java.util.Stack;
public class HistoryClear {
    // a Java program that simulates a browsing history using a stack.
    private static Stack<String> history = new Stack<>();

        public static boolean isBrowsingHistoryEmpty() {

            return history.isEmpty();
        }

        public static String mostRecentlyVisitedSite() {

            if (!history.isEmpty()) {
                return history.peek();
            } else {
                return "Browsing history is empty";
            }
        }

        public static void addSiteToHistory(String url) {

            history.push(url);
        }

        public static void goBackInTime(int n) {

            for (int i = 0; i < n && !history.isEmpty(); i++) {
                history.pop();
            }
        }

        public static void printBrowsingHistory() {

            if (!history.isEmpty()) {
                System.out.println(history);
            } else {
                System.out.println("Browsing History is empty");
            }
        }

        public static void main(String[] args) {
            System.out.println(isBrowsingHistoryEmpty());

            addSiteToHistory("www.google.co.in");
            addSiteToHistory("www.facebook.com");
            addSiteToHistory("www.upgrad.com");

            System.out.println(isBrowsingHistoryEmpty());
            System.out.println(mostRecentlyVisitedSite());

            addSiteToHistory("www.youtube.com");
            goBackInTime(2); // Go back by 2 sites

            addSiteToHistory("www.yahoo.com");
            System.out.println(mostRecentlyVisitedSite());

            printBrowsingHistory();
        }
    }


