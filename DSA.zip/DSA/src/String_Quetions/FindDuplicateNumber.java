package String_Quetions;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class FindDuplicateNumber {
    public static void main(String[] args) {
        int nums[] = {1, 3, 4, 2, 2};
        int duplicate = findDuplicate(nums);
        System.out.println(duplicate);

    }
        public static int findDuplicate(int[] nums) {
            Set<Integer> set = new HashSet<>();

            return Arrays.stream(nums)
                    .filter(n -> !set.add(n))
                    .findFirst()
                    .getAsInt();
        }

    }

