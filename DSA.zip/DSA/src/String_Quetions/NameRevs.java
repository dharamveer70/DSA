package String_Quetions;

public class NameRevs {
    public static void main(String[] args) {
        String name = "Dharamveer";
        int length = name.length();
        String nameRevs ="";
        for(int i = length-1;i>=0;--i){
            nameRevs = nameRevs+name.charAt(i);
        }
        System.out.println(nameRevs);
}
}
