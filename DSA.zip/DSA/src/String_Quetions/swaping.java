package String_Quetions;

public class swaping {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        System.out.println("Orignal Value "+a+" Value Two "+b);
//        int t = a; //t =10
//        a=b;  //a =20
//        b=t; //b = 10

        //without Third Variable
         a= a+b;
         b=a-b;
         a=a-b;
        System.out.println(a+" here "+b);


    }
}
