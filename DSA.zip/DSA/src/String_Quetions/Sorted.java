package String_Quetions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Sorted {

    public static void main(String[] args) {
        int []  number = {1,8,7,4,5,2,6,2,2};

//        List<Integer>   number1 = Arrays.stream(number).boxed().sorted().collect(Collectors.toList());
       List<Integer>   number2 = Arrays.stream(number).boxed().distinct().collect(Collectors.toList());
      // System.out.println(number2);
//
//
       String name = "Dharamveer";
       long name_a = name.chars().filter(a -> a == 'm').count();
     //   long number_a = Arrays.stream(number).boxed().filter(a->a =='1').count();
     //   System.out.println(number_a);
        System.out.println(name_a);




    }
}
