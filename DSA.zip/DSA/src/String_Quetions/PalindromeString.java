package String_Quetions;

import java.util.Scanner;

public class PalindromeString {

    public static void main(String[] args) {
        System.out.println("Enter String: ");
        Scanner sc = new Scanner(System.in);
        String str = sc.next();
        sc.close();  // Close the scanner

        // Use StringBuilder to reverse the string
        StringBuilder sb = new StringBuilder(str);
        String rev = sb.reverse().toString();

        // Check if the original string is equal to the reversed string
        if (str.equals(rev)) {
            System.out.println(str + " is a Palindrome String.");
        } else {
            System.out.println(str + " is Not a Palindrome String.");
        }
    }
}
