package Udemy_DSA;

public class Cookie {
    private String size;

    @Override
    public String toString() {
        return "Cookie{" +
                "size='" + size + '\'' +
                '}';
    }

    public Cookie(String size){
        this.size=size;
    }

    public static void main(String[] args) {

        Cookie c1 = new Cookie("10");
        Cookie c2 = new Cookie("20");
        Cookie c3 = new Cookie("30");
        System.out.println(c2);


    }
}
